/*
  Fontname: -FreeType-04b24-Medium-R-Normal--8-80-72-72-P-32-ISO10646-1
  Copyright: 20002003 / yuji oshimo�o / 04@dsg4.com / www.04.jp.org
  Capital A Height: 0, '1' Height: 5
  Calculated Max Values w= 3 h= 5 x= 0 y= 2 dx= 4 dy= 0 ascent= 5 len= 5
  Font Bounding box     w= 5 h= 6 x= 0 y=-1
  Calculated Min Values           x= 0 y=-1 dx= 0 dy= 0
  Pure Font   ascent = 5 descent= 0
  X Font      ascent = 5 descent= 0
  Max Font    ascent = 5 descent=-1
*/
#include "u8g.h"
const u8g_fntpgm_uint8_t u8g_font_04b_24n[136] U8G_FONT_SECTION("u8g_font_04b_24n") = {
  1,5,6,0,255,5,0,0,0,0,42,58,0,5,255,5,
  0,4,51,67,160,64,160,3,51,67,64,224,64,1,34,50,
  64,128,4,49,65,224,2,17,33,128,2,53,69,32,32,64,
  128,128,2,53,69,224,160,160,160,224,2,37,53,192,64,64,
  64,64,2,53,69,224,32,224,128,224,2,53,69,224,32,224,
  32,224,2,53,69,160,160,160,224,32,2,53,69,224,128,224,
  32,224,2,53,69,128,224,160,160,224,2,53,69,224,32,32,
  64,128,2,53,69,224,160,224,160,224,2,53,69,224,160,160,
  224,32,3,19,35,128,0,128};
